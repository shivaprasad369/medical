import React from 'react'

import About from './About'

import Mask from './Mask'
import Basic from './Basic'


import Why from './Why'
import Contact from './Contact'

import Footer1 from './Footer1'

import Banner1 from './Banner1'

import Blogs from './Blogs'
import Testimonials from '../ABout.jsx/Testimonials'
import About1 from './About1'
import Product from './Product'
import Header from './Header'
import BannerAbove from './BannerAbove'
import CustomSwiper from './Deliver'
import Banner3 from './Banner3'
import Banner from './Banner'
import Featured from './Featured'
import About3 from './About3'
export default function HomePage() {
  return (
    <>
  {/* <BannerAbove/> */}
  <Header/>
     <Banner1/>
     {/* <Banner3/> */}
<About/>
<CustomSwiper/>
    {/* <About1/> */}
     {/* <Deliver/> */}
     {/* <Banner1/> */}
     {/* <Product/> */}
     {/* <Featured/> */}
     {/* <About3/> */}
     {/* <Prevention/> */}
     <Mask/>
     <Basic/>
     <Blogs/>
     {/* <Protection/> */}
     {/* <Supply/> */}
     {/* <Feature/> */}
     {/* <Arrivals/> */}
     {/* <Testimonials/> */}
     {/* <Services/> */}
     <Why/>
     <Contact/>
     <Footer1/>
    </>
  )
}
