import img1 from '../../Assets/p1.png'
import img2 from '../../Assets/p2.png'
const data=[
    {
        id:1,
        type:'mask',
        category:'new arrials',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',
        image:'https://www.nubeno.in/wp-content/uploads/2024/10/Syringe-Luer-Lock.jpeg',
        name:'Hypodermic Syringse',
        price:'Rs. 4.86'
    },
    {
        id:2,
        type:'mask',
        category:'new arrials',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',

        image:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnItwTN5Np4w0aPx62SZUM-2dRlqbubTTveA&s',
        name:'Hypodermic Syringse',
        price:'Rs. 4.65'
    },
    {
        id:3,
        type:'mask',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',
        category:'new arrials',
        image:'https://www.kindly-group.com/uploads/IMG_8296.jpg',
        name:'Hypodermic Needels',
        price:'Rs. 4.86'
    },
    {
        id:4,
        type:'mask',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',
        category:'new arrials',
        image:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVilIu7e-uWHYUD4BpJn0G_VEhBKTNAB823w&s',
        name:'Drip Set',
        price:'Rs. 1.58'
    },
    {
        id:5,
        type:'mask',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',
        category:'new arrials',
        image:'https://www.freep.com/gcdn/authoring/2014/09/20/NOKL/ghnewsok-OK-5344014-443fc46e.jpeg?width=1733&height=1726&fit=crop&format=pjpg&auto=webp',
        name:'IV Fluids',
        price:'Rs. 1.04'
    },
    {
        id:6,
        type:'mask',
        desc:'The 20ml syringe is favored by many professional due to the clear easy to read marking for liquid withdrawal & injection.',
        category:'new arrials',
        image:'https://www.polymedicure.com/wp-content/uploads/2019/05/polyflex.jpg',
        name:'Cannula',
        price:'Rs. 4.08'
    }
]
export default data;