// // Import the functions you need from the SDKs you need
// import firebase from 'firebase';
// import { initializeApp } from "firebase/app";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries
// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyDWmYyk09lJ9ZnjIcJMCZ8ave76h_PEhTc",
//   authDomain: "form-94836.firebaseapp.com",
//   projectId: "form-94836",
//   storageBucket: "form-94836.appspot.com",
//   messagingSenderId: "275943911209",
//   appId: "1:275943911209:web:07df785fcbe4fb756f5138"
// };

// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// const Firebase=firebase.initializeApp(firebaseConfig);
// export default Firebase;

// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration


// // Initialize Firebase
